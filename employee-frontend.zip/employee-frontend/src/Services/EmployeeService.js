import axios from 'axios';
const EMPLOYEE_API_BASE_URL = "http://localhost:8080/employee/";
const EMPLOYEE_EXCEPT_ONE_API_BASE_URL = "http://localhost:8080/employee/except/";
const EMPLOYEE_UPDATE_API_BASE_URL = "http://localhost:8080/employee/update/";
const EMPLOYEE_DELETE_API_BASE_URL = "http://localhost:8080/employee/delete/";
class EmployeeService {

    async getEmployees(){
        return axios.get(EMPLOYEE_API_BASE_URL);
    }
    async getEmployeeById(id){
        return axios.get(EMPLOYEE_API_BASE_URL+id);
    }
    async addEmployee(data){
        axios.post(EMPLOYEE_UPDATE_API_BASE_URL,data);
    }
    async deleteEmployeeById(id){
        try{
            const res = await axios.delete(EMPLOYEE_DELETE_API_BASE_URL + id);
            if(res.status===200){console.log("success");}
            else console.log("failed")
            return res.status
        }catch(err){console.log(err)}
        
    }
     async getAllEmployeesExcept(id){
        return axios.get(EMPLOYEE_EXCEPT_ONE_API_BASE_URL + id);
    }

}

export default new EmployeeService()