import axios from 'axios';

const DEPARTMENT_API_BASE_URL = "http://localhost:8080/api/department";
const DEPT_API_BASE_URL = "http://localhost:8080/api/dept/";
class DepartmentService {

     async getDepartmentById(id){
        return axios.get(DEPT_API_BASE_URL + id);
    }
    getDepartments(){
        return axios.get(DEPARTMENT_API_BASE_URL);
    }
    async addDepartment(data){
        axios.post(DEPARTMENT_API_BASE_URL,data);
    }
}

export default new DepartmentService()