import React, { useEffect, useState } from 'react';
import EmployeeService from '../Services/EmployeeService';
import DepartmentService from '../Services/DepartmentService';
import { useParams } from 'react-router';

const UpdateEmployee = () => {
    const { id } = useParams();
    const [name, setName] = useState("");
    const [mail, setMail] = useState();
    const [d_id, setDid] = useState();
    const [d_name, setDname] = useState();
    const [manager, setManager] = useState();
    const [dob, setDob] = useState();

    const [employee, setEmployee] = useState([]);
    const [department, setDepartment] = useState([]);

    useEffect(() => {
        DepartmentService.getDepartments().then((res) => {
            setDepartment(res.data);
        });
    }, []);

    useEffect(() => {
        EmployeeService.getAllEmployeesExcept(id).then((res) => {
            setEmployee(res.data);
        });
    }, [id]);

    useEffect(() => {
        EmployeeService.getEmployeeById(id).then((res) => {
            setName(res.data.name);
            setMail(res.data.mail);
            setDid(res.data.department.d_id);
            setDname(res.data.department.d_name);
            setManager(res.data.manager_id);
            setDob(res.data.dob);
        });
    }, [id]);

    const handleSubmit = (event) => {
        event.preventDefault();
        const data = {
            id: id,
            name: name,
            mail: mail,
            department: { d_id: d_id, d_name: d_name },
            manager_id: manager,
            dob: dob,
        };
        console.log(data)
        EmployeeService.addEmployee(data);
    };

    const handleDepartmentChange = (id) => {
        console.log(id);
        DepartmentService.getDepartmentById(id).then((res) => {
            setDid(res.data.d_id);
            setDname(res.data.d_name);
        });
    };


    return (
        <div>
            <div className="container enroll">
                <div className="row justify-content-center">
                    <div className=" col-lg-6">
                        <h3 className="text-center">Update Employee</h3>
                        <div className="">
                            <form onSubmit={handleSubmit}>
                                <div className="form-group row p-2">
                                    <label className="col-sm-2" >Name</label>
                                    <input type="text" placeholder="name" name="name" className="col form-control"
                                        value={name ?? ""}
                                        onChange={(e) => setName(e.target.value)} />
                                </div>
                                <div className="form-group row p-2">
                                    <label className="col-sm-2">Mail</label>
                                    <input type="email" placeholder="Email" name="mail" className="col form-control"
                                        value={mail ?? ""}
                                        onChange={(e) => setMail(e.target.value)} />
                                </div>
                                <div className="form-group row p-2">
                                    <label className="col-sm-2">Dept</label>
                                    <select className="col form-control"
                                        onChange={(e) => handleDepartmentChange(e.target.value)} >
                                        <option hidden>{d_name} </option>
                                        {department.map((m) => {
                                            return d_id !== m.d_id ? (
                                                <option key={m.d_id} value={m.d_id} name={m.d_name}>
                                                    {m.d_name}
                                                </option>
                                            ) : ("");
                                        })
                                        }</select>
                                </div>
                                <div className="form-group row p-2">
                                    <label className="col-sm-2">Manager</label>
                                    <select className="col form-control"
                                        onChange={(e) => setManager(parseInt(e.target.value))}>
                                            <option hidden>Select manager </option>
                                        {employee.map((a) => {
                                            return (
                                                <option key={a.id} value={a.id} name={a.name}>
                                                    {a.name}
                                                </option>
                                            );
                                        })
                                        }</select>
                                </div>


                                <div className="form-group row p-2">
                                    <label className="col-sm-2">Dob</label>
                                    <input type="date" placeholder="DOB" name="dob" className="col form-control"
                                        value={dob ?? ""}
                                        onChange={(e) => setDob(e.target.value)} />
                                </div>
                                <div className="d-flex justify-content-center p-2">
                                    <button type="submit" className="btn btn-success">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}

export default UpdateEmployee;