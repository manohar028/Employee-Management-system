import React, { Component } from 'react';
import { HashLink as Link } from 'react-router-hash-link';
import EmployeeService from '../Services/EmployeeService';


class ListEmployeeComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            employee: []
        }
    }
    getEmp() {
        EmployeeService.getEmployees().then((res) => {
            this.setState({ employee: res.data });
        });
    }
    componentDidMount() {
        this.getEmp();
    }
    async deleteEmployee(id) {
        EmployeeService.deleteEmployeeById(id).then((res) => {
            if(res === 200){this.getEmp()}
        });
    }

    render() {
        return (
            <div>
                <h2 className="text-center">Employees List</h2>
                <div className="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Employee Name</th>
                                <th>Employee Mail</th>
                                <th>Employee DOB</th>
                                <th>Department </th>
                                <th>Manager Id</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.employee.map(
                                    employee =>
                                        <tr key={employee.id}>
                                            <td> {employee.name} </td>
                                            <td> {employee.mail} </td>
                                            <td> {employee.dob} </td>
                                            <td> {employee.department.d_name} </td>
                                            <td> {employee.manager_id} </td>
                                            <td>
                                                <Link to={"/update/" + employee.id} className="btn btn-primary">update</Link>
                                                <button onClick={()=>this.deleteEmployee(employee.id)} className="btn btn-danger" >Delete</button>
                                            </td>
                                        </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}

export default ListEmployeeComponent;