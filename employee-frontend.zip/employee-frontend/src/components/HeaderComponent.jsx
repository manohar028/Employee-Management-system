import React from 'react';
import {HashLink as Link} from 'react-router-hash-link';

const HeaderComponent = () =>{
    return(
        <div>
            <header>
                <div className=" navigation">
                    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                        <div className="row p-2">
                            <Link to="/" className= "nav navbar-brand col linkStyle">Employee Management System</Link>
                            <Link to="/addEmployee" className="nav navbar-brand col linkStyle">Add Employee</Link>
                        </div>
                    </nav>
                </div>
            </header>
        </div>
    )
};


    
export default HeaderComponent;